import { Routes } from '@angular/router';
import { FaqComponent } from './Faq/Faq.component';

export const FaqRoutes: Routes = [{

        path: '',
        component: FaqComponent
    }
];
