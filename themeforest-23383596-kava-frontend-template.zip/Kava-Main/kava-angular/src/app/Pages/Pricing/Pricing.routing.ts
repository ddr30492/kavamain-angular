import { Routes } from '@angular/router';
import { PricingComponent } from './Pricing/Pricing.component';

export const PricingRoutes : Routes = [{
		path: '',
		component: PricingComponent
	}
];
