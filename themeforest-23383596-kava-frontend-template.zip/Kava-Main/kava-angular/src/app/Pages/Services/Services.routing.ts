import { Routes } from '@angular/router';
import { ServicesComponent } from './Services/Services.component';

export const ServicesRoutes : Routes = [{
        path: '',
        component: ServicesComponent
    }
];
