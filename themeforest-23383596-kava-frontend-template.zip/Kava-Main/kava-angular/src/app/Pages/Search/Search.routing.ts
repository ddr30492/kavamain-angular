import { Routes } from '@angular/router';
import { SearchComponent } from './Search/Search.component';

export const SearchRoutes: Routes = [{
		path: '',
		component: SearchComponent
	}
];
