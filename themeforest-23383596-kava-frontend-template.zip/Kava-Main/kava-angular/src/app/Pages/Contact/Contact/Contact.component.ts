import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-contact',
	templateUrl: './Contact.component.html',
	styleUrls: ['./Contact.component.scss']
})

export class ContactComponent implements OnInit {

	constructor() { }

	ngOnInit() {
	}

}
