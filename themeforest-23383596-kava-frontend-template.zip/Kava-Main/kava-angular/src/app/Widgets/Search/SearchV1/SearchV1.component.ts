import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-v1',
  templateUrl: './SearchV1.component.html',
  styleUrls: ['./SearchV1.component.scss']
})
export class SearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
