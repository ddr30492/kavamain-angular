import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-map',
  templateUrl: './Map.component.html',
  styleUrls: ['./Map.component.scss']
})
export class MapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
