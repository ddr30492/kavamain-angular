import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lets-talk',
  templateUrl: './LetsTalk.component.html',
  styleUrls: ['./LetsTalk.component.scss']
})
export class LetsTalkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
