import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-content-v2',
  templateUrl: './ContactContentV2.component.html',
  styleUrls: ['./ContactContentV2.component.scss']
})
export class ContactContentV2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
