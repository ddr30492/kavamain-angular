import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-working-hours',
  templateUrl: './WorkingHours.component.html',
  styleUrls: ['./WorkingHours.component.scss']
})
export class WorkingHoursComponent implements OnInit {

	constructor() { }

	ngOnInit() {
	}

}
