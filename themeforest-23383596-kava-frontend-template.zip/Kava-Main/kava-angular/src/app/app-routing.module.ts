import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { MainComponent }   from './Main/Main.component';
import { HomeComponent } from './Pages/Home/Home.component';
import { ComingsoonComponent } from './Pages/Session/ComingSoon/ComingSoon.component';
import { MaintenanceComponent } from './Pages/Session/Maintenance/Maintenance.component';
import { LoginComponent } from './Pages/Session/LogIn/LogIn.component'
import { Signup2Component } from './Pages/Session/SignUp2/SignUp2.component'

export const AppRoutes: Routes = [{
   path: '',
   redirectTo: 'home',
   pathMatch: 'full',
   },{
      path: 'session/comingsoon',
      component : ComingsoonComponent
   },{
      path: 'session/maintenance',
      component: MaintenanceComponent
   },{
      path: 'session/login',
      component : LoginComponent
   },{
      path: 'session/signup2',
      component: Signup2Component
   },{
      path: '',
      component: MainComponent,
      children: [
         {
            path: 'home',
            component: HomeComponent
         },{
            path: 'blog',
            loadChildren: './Pages/Blog/Blog.module#BlogModule'
         },{
            path: 'team',
            loadChildren: './Pages/Team/Team.module#TeamModule'
         },{
            path: 'portfolio',
            loadChildren: './Pages/Portfolio/Portfolio.module#PortfolioModule'
         },{
            path: 'pages/services',
            loadChildren: './Pages/Services/Services.module#ServicesModule'
         },{
            path: 'session',
            loadChildren: './Pages/Session/Session.module#SessionModule'
         },{
            path: 'contact',
            loadChildren: './Pages/Contact/Contact.module#ContactModule'
         },{
            path: 'pages/faq',
            loadChildren: './Pages/Faq/Faq.module#FaqModule'
         },{
            path: 'pages/pricing',
            loadChildren: './Pages/Pricing/Pricing.module#PricingModule'
         },{
            path: 'pages/search',
            loadChildren: './Pages/Search/Search.module#SearchModule'
         },{
            path: 'about-us',
            loadChildren: './Pages/AboutUs/AboutUs.module#AboutUsModule'
         }
      ]
   }
];

@NgModule({
   imports: [
      CommonModule,
      RouterModule.forRoot(AppRoutes)
   ],
   exports: [RouterModule],
   declarations: []
})
export class AppRoutingModule { }
